Release packet A
Owner: Data Ops
Do not trust checksum rows until verified.
